module.exports = {
  extends: ['wesbos'],
  rules: {
    'arrow-body-style': 'off',
    'react/no-danger': false,
  },
};
